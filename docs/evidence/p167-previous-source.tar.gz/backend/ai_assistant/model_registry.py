"""
Model registry for the AI Assistant.

Defines supported LLM providers (OpenAI, local Inference Engine) and their
model configurations. Each model entry specifies the provider, model id,
display name, and default generation parameters. The _call_llm() helper selects
the right SDK at runtime.

The ``engine`` provider routes calls to a local llm-inference-engine instance
via its OpenAI-compatible ``/v1/chat/completions`` endpoint. We intentionally
talk to it through the OpenAI Python SDK so the prometa-sdk's openai
auto-instrumentation captures gen_ai.* spans on the assistant side — agentic-
hook-v2 stays decoupled from any specific inference backend.

Engine models are **discovered dynamically** from the engine's
``GET /v1/models`` endpoint rather than hard-coded.  The engine itself
probe-loads each GGUF and only lists ones llama.cpp can actually open, so
DeclarAI's UI surfaces only models that will actually answer.  A small
in-process TTL cache keeps Django request latency unaffected by the extra
RTT.
"""

import logging
import os
import re
import threading
import time

# ---------------------------------------------------------------------------
# Registry: model_key → config
# ---------------------------------------------------------------------------
# Architecture / capability tags exposed to the frontend model selector.
#   architecture:    'dense' | 'moe'
#   reasoning:       model is optimised for chain-of-thought reasoning
#   thinking:        model can emit an explicit thinking / scratchpad block
#   thinking_level:  None | 'low' | 'med' | 'high'

MODEL_REGISTRY = {
    # ── OpenAI (cloud) ────────────────────────────────────────────────
    'gpt-5.5': {
        'provider': 'openai',
        'model_id': 'gpt-5.5',
        'display_name': 'GPT-5.5 (OpenAI)',
        'max_tokens': 16384,
        'supports_tools': True,
        'is_reasoning_model': True,
        'architecture': 'moe',
        'reasoning': True,
        'thinking': True,
        'thinking_level': 'high',
        'tool_calling_mode': 'native',
    },
    'gpt-5.4-mini': {
        'provider': 'openai',
        'model_id': 'gpt-5.4-mini',
        'display_name': 'GPT-5.4 Mini (OpenAI)',
        'max_tokens': 16384,
        'supports_tools': True,
        'is_reasoning_model': True,
        'architecture': 'moe',
        'reasoning': True,
        'thinking': True,
        'thinking_level': 'med',
        'tool_calling_mode': 'native',
    },
    'gpt-4.1-mini': {
        'provider': 'openai',
        'model_id': 'gpt-4.1-mini',
        'display_name': 'GPT-4.1 Mini (OpenAI)',
        'max_tokens': 16384,
        'supports_tools': True,
        'is_reasoning_model': False,
        'architecture': 'moe',
        'reasoning': False,
        'thinking': False,
        'thinking_level': None,
        'tool_calling_mode': 'native',
    },
    # Engine entries (provider='engine') are populated dynamically from
    # ``GET {LLM_ENGINE_BASE_URL}/models`` — see ``_refresh_engine_models()``.
    # Keys follow the convention ``engine-{engine_id_with_colons_dashed}``,
    # so ``llama3.2:3b`` becomes ``engine-llama3.2-3b``.
}

# Preferred default is the local gemma4:26b engine model.  Cloud GPT is only
# used when the engine has not advertised gemma4:26b (cold boot / unreachable).
PREFERRED_DEFAULT_MODEL = 'engine-gemma4-26b'
CLOUD_FALLBACK_MODEL = 'gpt-5.5'
# Public alias kept for existing imports; always the preferred engine key.
DEFAULT_MODEL = PREFERRED_DEFAULT_MODEL

# Metadata keys surfaced to the frontend model selector
_MODEL_META_KEYS = (
    'architecture', 'reasoning', 'thinking', 'thinking_level', 'ram_gb',
    'tool_calling_mode',
)

# Registry shape kept identical to the static entries above so the rest of
# the code (views, tests, frontend payloads) doesn't need to know whether a
# given engine entry was hard-coded or fetched.
_logger = logging.getLogger(__name__)

# TTL controls how often we re-poll the engine's /v1/models endpoint.  Long
# enough to make repeated Django requests free, short enough that pulling a
# new ollama model becomes visible to DeclarAI within a minute without a
# server restart.  Override via env for tests.
_ENGINE_MODELS_TTL_SECONDS = float(os.environ.get('LLM_ENGINE_MODELS_TTL', '60'))
_ENGINE_MODELS_TIMEOUT = float(os.environ.get('LLM_ENGINE_MODELS_TIMEOUT', '5.0'))

_engine_cache_lock = threading.Lock()
_engine_cache: dict[str, dict] = {}
_engine_cache_expires_at: float = 0.0

# Engine-discovery health, surfaced via ``engine_status()`` and the /models
# endpoint.  Its whole reason to exist: when the engine is briefly unreachable
# DeclarAI falls back to a cloud-only model list, and pre-this-change that
# fallback was **silent** — the frontend couldn't tell "engine has no models"
# apart from "engine discovery failed", so a transient cold-boot miss looked
# identical to a healthy OpenAI-only deployment.  We now record the outcome of
# every real discovery attempt so the degradation is observable and explained.
# Mutated only while holding ``_engine_cache_lock``.
_engine_health: dict = {
    'available': False,   # did the most recent discovery attempt succeed?
    'model_count': 0,     # engine models currently in the served snapshot
    'last_error': None,   # short string describing the most recent failure
    'checked_at': None,   # wall-clock epoch seconds of the last attempt (None = never)
}
# Scratch slot: ``_fetch_engine_models`` stashes its failure reason here on the
# error path so ``_refresh_engine_models`` (which owns ``_engine_health``) can
# fold it into the structured health dict under the lock.  Only ever written on
# a failure; the caller sets ``last_error`` back to None on success.
_engine_last_error: "str | None" = None


# Parameter-size pattern: optional digits + optional decimal + b/m suffix.
# Matches "26b", "3b", "1.5b", "8b", "e2b" (gemma's embedded variant — the
# leading 'e' is rejected by \d+ so the scan resumes at '2b'), "e4b", "70b",
# "1m" (tiny test models).  Anchored to end-of-string with an optional
# ``[-_].*`` tail so suffixes like "26b-q4" still extract "26b" cleanly
# (the leading numeric run wins) and an embedded "1B" inside a family
# string like ``Llama-3.2-1B-Instruct-4bit`` matches because the trailing
# ``-Instruct-4bit`` is absorbed by the optional ``[-_].*`` tail.
_OLLAMA_PARAM_SIZE_RE = re.compile(r'(\d+(?:\.\d+)?[bm])(?:[-_].*)?$', re.IGNORECASE)


def parse_ollama_tag(model_id: str) -> dict:
    """Split an Ollama-style model id into ``{family, tag, parameter_size}``.

    The local llm-inference-engine surfaces models with names of the form
    ``family:variant`` — for example ``gemma4:26b``, ``llama3.2:3b``,
    ``nemotron-3-nano:30b``, ``minimax-m2.7:cloud``.  Prometa's pricing
    registry uses a ``startsWith(registryKey)`` matcher that doesn't
    understand the ``:variant`` suffix or the family/size split, so it
    treats every self-hosted span as ``cost=0`` silent-zero (see thread
    with prometa-platform team 2026-05-28).

    Returning the components separately lets ``_call_llm`` stamp them as
    individual span attributes (``gen_ai.model.family``,
    ``gen_ai.model.tag``, ``gen_ai.model.parameter_size``) so the
    matcher can route on whichever facet it prefers without us breaking
    the canonical ``gen_ai.request.model`` wire format.

    Shape:
        ``family``         — substring before the first ``:`` (or the
                             whole id when no colon is present).  Always
                             a string; empty input yields ``''``.
        ``tag``            — substring after the first ``:``, or
                             ``None`` when no colon is present.
        ``parameter_size`` — extracted via regex.  Tried first on the
                             tag (typical Ollama-style: ``family:26b``),
                             then on the family as a fallback so MLX/HF
                             converted ids like
                             ``Llama-3.2-1B-Instruct-4bit:mlx`` still
                             surface ``parameter_size=1b``.  ``None``
                             when neither side carries a ``<digits>[bm]``
                             segment.  Normalized to lowercase.  Examples:
                                 ``gemma4:26b``                → ``"26b"``
                                 ``gemma4:e2b``                → ``"2b"``
                                 ``ministral-3:1.5b``          → ``"1.5b"``
                                 ``minimax-m2.7:cloud``        → ``None``
                                 ``Llama-3.2-1B-Instruct:mlx`` → ``"1b"``

    The function never raises on malformed input — callers can stamp
    whichever subset of fields came back non-empty without guarding.
    """
    if not isinstance(model_id, str) or not model_id:
        return {'family': '', 'tag': None, 'parameter_size': None}
    head, sep, tail = model_id.partition(':')
    family = head
    tag = tail if sep else None
    parameter_size = None
    # Try the tag first — that's where Ollama puts the size for
    # vanilla pulls (``family:26b``).  Fall back to scanning the
    # family for MLX/HF converted ids that encode the size in the
    # family string (``Llama-3.2-1B-Instruct-4bit:mlx``).
    if tag:
        match = _OLLAMA_PARAM_SIZE_RE.search(tag)
        if match:
            parameter_size = match.group(1).lower()
    if parameter_size is None and family:
        match = _OLLAMA_PARAM_SIZE_RE.search(family)
        if match:
            parameter_size = match.group(1).lower()
    return {'family': family, 'tag': tag, 'parameter_size': parameter_size}


def _engine_key(engine_id: str) -> str:
    """Map an engine model id (e.g. ``llama3.2:3b``) to a DeclarAI key.

    Convention: prefix with ``engine-`` and replace ``:`` separators with
    ``-`` so the key is URL/path safe, while preserving the original ``id``
    structure so the round-trip is unambiguous (no two distinct ollama tags
    can collide after the substitution because ``-`` is otherwise legal).
    """
    return f"engine-{engine_id.replace(':', '-')}"


def _display_name_for(engine_id: str) -> str:
    """Pretty label shown in the model selector — derived, not configured.

    Operators can pull arbitrary models into ollama; we don't get to write a
    bespoke display string for each one.  Keeping the engine id verbatim is
    honest and makes provenance obvious to users (they can grep it against
    ``ollama list``).
    """
    return f"{engine_id} (Inference Engine)"


def _ram_gb_estimate(size_bytes: int) -> int:
    """Coarse RAM hint shown in the UI.

    The engine reports ``size_bytes`` (the GGUF blob size).  Resident
    footprint at runtime is dominated by weights + KV cache; for a quick UI
    hint we use ceil(size_bytes / 1 GB) which over-estimates slightly on
    quantised weights — preferable to under-estimating and OOM-ing the host.
    """
    if size_bytes <= 0:
        return 0
    gb = size_bytes / (1024 ** 3)
    return max(1, int(gb + 0.999))


def _build_engine_entry(model_data: dict) -> dict:
    """Translate one entry from the engine's ``/v1/models`` payload.

    The engine surfaces capability metadata per-model on ``/v1/models`` —
    ``reasoning`` / ``thinking`` / ``thinking_level`` / ``tool_calling_mode``
    — based on its ``infer_model_capabilities`` heuristic (e.g. anything
    matching ``nemotron|deepseek-r1|qwen3-thinking|qwq|...`` is flagged as
    reasoning).  We mirror those flags into the DeclarAI registry so the
    frontend can render badges correctly AND so ``call_engine`` can opt
    reasoning-family models into ``chat_template_kwargs.enable_thinking``
    (see ``call_engine`` for why this matters — without it the chat
    template tells Nemotron its think block is already closed and the
    model leaks raw CoT into ``content``).

    Fields missing from the engine payload fall back to safe non-reasoning
    defaults so older engine builds that pre-date the capability surface
    keep working unchanged.
    """
    engine_id = model_data['id']
    # The engine may surface tool_calling_mode per model; default to 'text'
    # since most open-source models use text-based action blocks.
    tcm = model_data.get('tool_calling_mode', 'text')
    return {
        'provider': 'engine',
        'model_id': engine_id,
        'display_name': _display_name_for(engine_id),
        'temperature': 0.4,
        'max_tokens': 4096,
        'supports_tools': True,
        'architecture': 'dense',
        'reasoning': bool(model_data.get('reasoning', False)),
        'thinking': bool(model_data.get('thinking', False)),
        'thinking_level': model_data.get('thinking_level'),
        'ram_gb': _ram_gb_estimate(int(model_data.get('size_bytes', 0))),
        'tool_calling_mode': tcm,
    }


def _fetch_engine_models() -> dict[str, dict] | None:
    """Hit ``GET {LLM_ENGINE_BASE_URL}/models`` and translate the response.

    Returns ``None`` (not ``{}``) on failure so the caller can keep serving
    the previous cached snapshot rather than wiping the UI when the engine
    is briefly unreachable.
    """
    base_url = os.environ.get('LLM_ENGINE_BASE_URL', 'http://llm-engine:8080/v1')
    api_key = os.environ.get('LLM_ENGINE_API_KEY', 'sk-engine-local')
    url = base_url.rstrip('/') + '/models'

    # Use the stdlib HTTP client to avoid pulling httpx into Django's import
    # graph — DeclarAI already imports openai for the actual chat path.
    import urllib.request
    import urllib.error
    import json
    req = urllib.request.Request(url, headers={'Authorization': f'Bearer {api_key}'})
    try:
        with urllib.request.urlopen(req, timeout=_ENGINE_MODELS_TIMEOUT) as resp:
            payload = json.loads(resp.read().decode('utf-8'))
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError, OSError) as exc:
        global _engine_last_error
        _engine_last_error = f"{type(exc).__name__}: {exc}"
        _logger.warning("engine /v1/models fetch failed: %s", exc)
        return None

    out: dict[str, dict] = {}
    for entry in payload.get('data') or []:
        try:
            cfg = _build_engine_entry(entry)
        except (KeyError, TypeError, ValueError) as exc:
            _logger.warning("engine model entry malformed (%s): %r", exc, entry)
            continue
        out[_engine_key(cfg['model_id'])] = cfg

    unavailable = payload.get('unavailable') or []
    if unavailable:
        _logger.info(
            "engine reports %d unavailable model(s): %s",
            len(unavailable),
            ", ".join(f"{u.get('id')} ({u.get('reason')})" for u in unavailable),
        )
    return out


def _refresh_engine_models(force: bool = False) -> dict[str, dict]:
    """Return the engine entries, refreshing the cache if the TTL elapsed.

    On a fetch failure we return the previous snapshot (possibly empty on
    cold boot) — DeclarAI degrades to "no engine models" but stays up.  The
    OpenAI block in ``MODEL_REGISTRY`` keeps the assistant usable.
    """
    global _engine_cache, _engine_cache_expires_at
    now = time.monotonic()
    with _engine_cache_lock:
        if not force and now < _engine_cache_expires_at:
            return _engine_cache

        fetched = _fetch_engine_models()
        checked_at = time.time()
        if fetched is None:
            # Discovery failed.  Keep the last-known-good cache (which may be
            # empty on cold boot) so the assistant stays up, but record WHY so
            # ``engine_status()`` / the /models endpoint can report a degraded
            # engine instead of silently serving cloud-only.  Back off briefly
            # so we don't hammer a restarting engine on every Django request.
            _engine_cache_expires_at = now + min(_ENGINE_MODELS_TTL_SECONDS, 5.0)
            _engine_health.update({
                'available': False,
                'model_count': len(_engine_cache),
                'last_error': _engine_last_error or 'engine discovery failed',
                'checked_at': checked_at,
            })
            return _engine_cache

        _engine_cache = fetched
        _engine_cache_expires_at = now + _ENGINE_MODELS_TTL_SECONDS
        _engine_health.update({
            'available': True,
            'model_count': len(fetched),
            'last_error': None,
            'checked_at': checked_at,
        })
        return _engine_cache


def _registry_snapshot() -> dict[str, dict]:
    """Merged view: static cloud entries + dynamic engine entries.

    Keyed by DeclarAI key.  Cloud entries always win on collision since the
    engine is unlikely to ever advertise a key starting with ``gpt-``; we
    enforce it anyway as defense-in-depth.
    """
    snapshot = dict(_refresh_engine_models())
    snapshot.update(MODEL_REGISTRY)
    return snapshot


def resolve_default_model(snapshot=None) -> str:
    """Return the model key that should be the UI/chat default.

    Prefers ``engine-gemma4-26b`` (``gemma4:26b``) when the inference engine
    has advertised it.  Falls back to any ``gemma4*26b`` engine entry, then
    to ``gpt-5.5`` so the assistant stays usable when the engine is down.
    """
    snap = snapshot if snapshot is not None else _registry_snapshot()
    if PREFERRED_DEFAULT_MODEL in snap:
        return PREFERRED_DEFAULT_MODEL
    for key, cfg in snap.items():
        model_id = str(cfg.get('model_id') or '').lower()
        if model_id == 'gemma4:26b' or (
            model_id.startswith('gemma4') and '26b' in model_id
        ):
            return key
        if key == 'engine-gemma4-26b' or (
            key.startswith('engine-gemma4') and '26b' in key
        ):
            return key
    if CLOUD_FALLBACK_MODEL in snap:
        return CLOUD_FALLBACK_MODEL
    # Last resort: first registered model, else the preferred key string
    if snap:
        return next(iter(snap.keys()))
    return PREFERRED_DEFAULT_MODEL


def get_model_config(model_key: str) -> dict:
    """Return config for a model key, falling back to the resolved default."""
    snapshot = _registry_snapshot()
    if model_key in snapshot:
        return snapshot[model_key]
    default_key = resolve_default_model(snapshot)
    if default_key in snapshot:
        return snapshot[default_key]
    # Extremely defensive: prefer cloud fallback dict from static registry
    return MODEL_REGISTRY[CLOUD_FALLBACK_MODEL]


def list_models() -> list:
    """Return list of available models for the frontend selector."""
    snapshot = _registry_snapshot()
    return [
        {
            'key': k,
            'display_name': v['display_name'],
            'provider': v['provider'],
            **{mk: v.get(mk) for mk in _MODEL_META_KEYS},
        }
        for k, v in snapshot.items()
    ]


def engine_status() -> dict:
    """Health snapshot of engine model discovery, for the /models endpoint & ops.

    Returns a *copy* so callers can't mutate the shared health dict.  Fields:
        ``available``   — did the most recent discovery attempt succeed?
        ``model_count`` — engine models currently in the served list.
        ``last_error``  — reason for the most recent failure (None when healthy).
        ``checked_at``  — epoch seconds of the last attempt (None = not yet checked).

    This is the signal that turns a cloud-only model list from a *silent*
    fallback into an *explained* degraded state the frontend can surface.
    """
    with _engine_cache_lock:
        return dict(_engine_health)


def invalidate_engine_cache() -> None:
    """Drop the engine model cache — useful for tests and ops poking.

    Clears both the cached engine entries and the discovery-health snapshot, so
    the next ``_refresh_engine_models()`` re-discovers from scratch and
    ``engine_status()`` reports unavailable / unchecked until it does.  (Note
    this is deliberately more aggressive than the *live* TTL-expiry path in
    ``_refresh_engine_models``, which keeps the last-known-good entries as a
    fallback while the engine restarts.)
    """
    global _engine_cache_expires_at, _engine_cache
    with _engine_cache_lock:
        _engine_cache = {}
        _engine_cache_expires_at = 0.0
        _engine_health.update({
            'available': False,
            'model_count': 0,
            'last_error': None,
            'checked_at': None,
        })


# ---------------------------------------------------------------------------
# Unified LLM caller
# ---------------------------------------------------------------------------

def call_openai(api_key: str, messages: list, model_cfg: dict,
                tools: list = None) -> dict:
    """Call OpenAI chat completions API."""
    from openai import OpenAI
    client = OpenAI(api_key=api_key, timeout=90.0)

    kwargs = {
        'model': model_cfg['model_id'],
        'messages': messages,
        'max_completion_tokens': model_cfg.get('max_tokens', 8192),
    }
    # Reasoning models (gpt-5.x) don't support custom temperature
    if not model_cfg.get('is_reasoning_model'):
        kwargs['temperature'] = model_cfg.get('temperature', 0.4)
    if tools and model_cfg.get('supports_tools'):
        kwargs['tools'] = tools
        kwargs['tool_choice'] = 'auto'

    response = client.chat.completions.create(**kwargs)
    return response.model_dump()


def _recover_reasoning_content(response: dict) -> dict:
    """Salvage a real answer that the engine routed into ``reasoning_content``.

    v2.43.2 — the llm-inference-engine team (PR fix/blocking-normalizer-
    reasoning-prelude) chose the AGGRESSIVE blocking-path policy: for a
    reasoning-family model, unanchored text (no ``<think>``/``</think>``
    markers, no tool_calls) routes to ``reasoning_content`` regardless of
    ``finish_reason`` — so the blocking path is byte-for-byte symmetric with
    StreamNormalizer, which can't retract already-sent SSE frames.

    Their stated trade-off: in the rare case a reasoning model emits a real
    answer with NO ``<think>`` markers at all, that answer lands in
    ``reasoning_content`` instead of ``content``.  They assumed DeclarAI
    renders reasoning collapsed-by-default and could recover it.  We do NOT:
    every consumer (``_chat_workflow`` in views.py, the Angular chat panel)
    reads only ``message.content``.  Left unhandled, such an answer would be
    silently dropped — ``_chat_workflow`` would see empty content, burn a
    synthesis pass, then fall back to ``_EMPTY_RESPONSE_FALLBACK`` and the
    user would see "the assistant did not return an answer this time."

    This guard makes our consumer robust to EITHER engine policy
    (aggressive-now or conservative-later): whenever a choice has blank
    ``content`` but a populated ``reasoning_content`` AND no tool_calls (a
    tool-call round legitimately has empty content), we promote
    ``reasoning_content`` into ``content`` so downstream code sees the
    answer.  The original ``reasoning_content`` is preserved on the message
    for any future collapsed-CoT renderer.

    v2.44.0 refinement: we promote ONLY when ``finish_reason == 'stop'`` (a
    complete answer the engine misrouted).  When ``finish_reason == 'length'``
    the reasoning_content is UNFINISHED chain-of-thought — the model ran out
    of budget mid-thought — and promoting it leaks raw CoT to the user.  We
    leave content empty in that case and tag the choice
    ``declarai_reasoning_truncated`` so ``_chat_workflow`` runs its
    finalization pass instead.

    Idempotent and defensive: tolerates missing keys / non-dict shapes and
    never raises (a salvage helper must not be able to break the chat path).
    """
    try:
        choices = response.get('choices') or []
    except AttributeError:
        return response
    for choice in choices:
        if not isinstance(choice, dict):
            continue
        msg = choice.get('message')
        if not isinstance(msg, dict):
            continue
        # A tool-call round legitimately has empty content — leave it alone.
        if msg.get('tool_calls'):
            continue
        content = msg.get('content')
        if content and content.strip():
            continue
        reasoning = msg.get('reasoning_content')
        if not (isinstance(reasoning, str) and reasoning.strip()):
            continue
        # v2.44.0: do NOT promote when the model was cut off mid-thought
        # (finish_reason == 'length').  In that case reasoning_content holds
        # UNFINISHED chain-of-thought — not a deliverable answer — and
        # promoting it leaks raw CoT to the user ("Okay, let's tackle this
        # problem.  The user wants…", reproduced live as a 15.6 KB monologue).
        # That was the exact screenshot bug.  Leaving content empty lets
        # ``_chat_workflow``'s finalization/synthesis pass produce a clean
        # reply from the tool results instead.  A COMPLETE answer that the
        # engine merely misrouted into reasoning_content finishes with 'stop'
        # (the v2.43.2 case) — those we still promote.
        if choice.get('finish_reason') == 'length':
            choice['declarai_reasoning_truncated'] = True
            _logger.warning(
                "Skipped promoting %d chars of truncated reasoning_content "
                "(finish_reason=length) — unfinished CoT, deferring to the "
                "finalization pass.",
                len(reasoning),
            )
            continue
        msg['content'] = reasoning
        choice['declarai_reasoning_recovered'] = True
        _logger.warning(
            "Recovered %d chars from reasoning_content into content "
            "(engine routed an unanchored answer as reasoning).",
            len(reasoning),
        )
    return response


# ---------------------------------------------------------------------------
# Engine admission telemetry (llm-inference-engine PR #107)
# ---------------------------------------------------------------------------
# The engine stamps the scheduler lease that ADMITTED this request onto the
# response headers.  Before this existed, the entire span between "request
# sent" and "first byte back" was one opaque block to us, so the chat panel
# labelled it "Thinking" — a guess that reads as wrong precisely when the
# request was actually queued.
#
# Four contract rules from the engine team, each of which the parser below
# encodes.  Getting any of them wrong produces exactly the class of misleading
# progress this channel exists to remove:
#
#   1. They describe the admission that STARTED the response — the first
#      lease.  A request that falls back to another model, or retries a schema
#      repair, is admitted again and that later wait is NOT counted here.
#   2. Both depths count the request itself, so an admitted request under a
#      live scheduler always reports at least 1.  "Requests ahead of you" is
#      therefore ``depth - 1``, never ``depth``.
#   3. A depth of 0 means the scheduler is DISABLED and nothing queued at all
#      — semantically different from 1 ("admitted, nobody else waiting").
#   4. Absent, never zeroed, when a request never reached the scheduler.
#      "Did not queue" must stay distinguishable from "queued for 0 ms", so a
#      missing header yields a missing key rather than a 0.
#
# Note on which path we're on: we call the engine in BLOCKING mode, so these
# headers arrive with the completed response — they let us attribute time
# retrospectively ("9s of that 12s was queue, not thinking"), not narrate the
# wait live.  Live queue display would require switching call_engine to
# streaming, where the engine flushes these at stream open ahead of the first
# delta.  That is a separate, much larger change.
QUEUE_WAIT_MS_HEADER = 'x-engine-queue-wait-ms'
QUEUE_DEPTH_HEADER = 'x-engine-queue-depth'
TENANT_QUEUE_DEPTH_HEADER = 'x-engine-tenant-queue-depth'
RESOURCE_HEADER = 'x-engine-resource'


def parse_admission_headers(headers) -> dict:
    """Read the engine's admission headers into a plain dict.

    Returns ``{}`` when the request never reached the scheduler (rule 4).
    Malformed values are dropped rather than coerced — a telemetry field must
    never be able to break a completion the user already waited for.
    """
    if not headers:
        return {}

    def _int(name):
        raw = headers.get(name)
        if raw is None:
            return None
        try:
            return int(str(raw).strip())
        except (TypeError, ValueError):
            return None

    admission = {}
    wait_ms = _int(QUEUE_WAIT_MS_HEADER)
    if wait_ms is not None:
        admission['queue_wait_ms'] = wait_ms
    depth = _int(QUEUE_DEPTH_HEADER)
    if depth is not None:
        admission['queue_depth'] = depth
    tenant_depth = _int(TENANT_QUEUE_DEPTH_HEADER)
    if tenant_depth is not None:
        admission['tenant_queue_depth'] = tenant_depth
    resource = headers.get(RESOURCE_HEADER)
    if resource:
        admission['resource'] = str(resource)
    return admission


def call_engine(messages: list, model_cfg: dict, tools: list = None) -> dict:
    """Call the local llm-inference-engine via its OpenAI-compatible API.

    We use the OpenAI Python SDK with a custom ``base_url`` (rather than
    raw HTTP) for one specific reason: the prometa-sdk's openai integration
    auto-instruments ``Completions.create``, so every engine call emits the
    same ``gen_ai.*`` spans (prompt, completion, tokens) that the cloud
    GPT path emits today. agentic-hook-v2 receives all observability data
    from the assistant side; the engine itself stays free of any
    prometa/agentic-hook-v2 dependency.

    Configuration is via env vars:
      LLM_ENGINE_BASE_URL  — defaults to http://llm-engine:8080/v1
      LLM_ENGINE_API_KEY   — bearer token (engine accepts any value when
                              its AUTH_ENABLED=false; required when on)

    v2.43.1 — for reasoning-family models (Nemotron, DeepSeek-R1, Qwen3-
    Thinking, QwQ, …) we pass ``chat_template_kwargs={'enable_thinking':
    True}`` to the engine.  Their GGUF chat templates branch on a Jinja
    ``enable_thinking`` variable: when it's falsy (the default when no
    client passes it), the template pre-emits ``<think></think>`` — i.e.
    tells the model its think block is already done — but a reasoning-
    trained model produces CoT prose anyway, just *without* ``<think>``
    markers.  Setting ``enable_thinking=True`` makes the template pre-emit
    ``<think>\n`` instead, which makes the wire output more explicit when
    the model does close the block.  The flag is a documented OpenAI-
    extension (vLLM and Ollama HTTP both honour it the same way) so this
    is correct configuration for reasoning models, **not a leak fix**.
    The actual leak fix has to land engine-side: the blocking-path
    response normalizer needs an ``expects_reasoning_prelude`` flag that
    mirrors the streaming path, so the engine can correctly classify
    raw-CoT-without-markers as reasoning when the model exhausts
    ``max_tokens`` before closing ``</think>``.  Filed as engine feedback
    in ``docs/engine-feedback/nemotron-cot-leak-blocking-normalizer.md``.
    """
    import httpx
    from openai import OpenAI

    base_url = os.environ.get('LLM_ENGINE_BASE_URL', 'http://llm-engine:8080/v1')
    # The engine accepts any token when AUTH_ENABLED=false; the OpenAI SDK
    # rejects an empty api_key, so we pass a placeholder when none is set.
    api_key = os.environ.get('LLM_ENGINE_API_KEY', 'sk-engine-local')

    # ── Admission headers via an httpx event hook ───────────────────────
    # The parsed OpenAI response object carries no headers, and the SDK only
    # exposes them through ``with_raw_response`` — a different call path.  We
    # route engine traffic through the plain SDK method *specifically* so
    # prometa-sdk's openai auto-instrumentation wraps it (see module docstring),
    # so changing the call path to read a telemetry header would risk the
    # gen_ai.* spans that are the whole reason this indirection exists.
    #
    # A transport-level event hook sidesteps that entirely: the SDK call site
    # is untouched, and the hook sees the response headers before the body is
    # read.  The client is per-call, so the captured admission belongs to this
    # request and no locking is needed.
    admission: dict = {}

    def _capture_admission(response) -> None:
        try:
            admission.update(parse_admission_headers(response.headers))
        except Exception:  # pragma: no cover - telemetry must never fail a call
            pass

    http_client = httpx.Client(
        timeout=300.0,
        event_hooks={'response': [_capture_admission]},
    )
    client = OpenAI(api_key=api_key, base_url=base_url, timeout=300.0,
                    http_client=http_client)

    kwargs = {
        'model': model_cfg['model_id'],
        'messages': messages,
        'max_tokens': model_cfg.get('max_tokens', 4096),
        'temperature': model_cfg.get('temperature', 0.4),
    }
    if tools and model_cfg.get('supports_tools'):
        kwargs['tools'] = tools
        kwargs['tool_choice'] = 'auto'
    # Reasoning-family models need an explicit ``enable_thinking=True`` to
    # avoid the silent CoT-into-content leak — see docstring above.
    if model_cfg.get('reasoning'):
        kwargs['extra_body'] = {
            'chat_template_kwargs': {'enable_thinking': True},
        }

    try:
        response = client.chat.completions.create(**kwargs)
    finally:
        # The SDK does not own a client we passed in, so we close it.
        http_client.close()
    # v2.43.2: the engine's aggressive blocking-path policy can route a real
    # answer into ``reasoning_content`` when the model emits no ``<think>``
    # markers.  We read only ``message.content`` downstream, so promote any
    # such answer back into ``content`` before returning — see
    # ``_recover_reasoning_content`` for the full rationale.
    result = _recover_reasoning_content(response.model_dump())
    if admission:
        # Namespaced like ``declarai_reasoning_truncated`` on the choice: a
        # local annotation on an otherwise OpenAI-shaped payload.  Absent when
        # the request never queued, so downstream can tell "did not queue"
        # from "queued for 0 ms".
        result['declarai_admission'] = admission
    return result
