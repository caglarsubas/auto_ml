"""Shared booster adapters for XGBoost / LightGBM / CatBoost.

Keeps the boosting pipeline algorithm-agnostic while preserving the existing
product flow (native categoricals, early stopping, gain importance, SHAP).
"""

from __future__ import annotations

import json
import os
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from modeling.declared_metric import CatBoostDeclaredMetric, metric_value, prepare_metric, record_stopping


_NO_MATRIX_LABEL = object()


def _small_native_numeric_matrix(frame):
    """Bounded current-value conversion for a qualified mixed pandas frame.

    XGBoost 2.1.4 stores these columns as float32, including categorical codes.
    Preserve its feature types and let DMatrix perform all native validation.
    Unsupported storage, overflow and large frames keep the pandas route.
    """
    if not frame.columns.is_unique or frame.size > 2**18:
        return None
    dtypes = list(frame.dtypes)
    if not any(isinstance(t, pd.CategoricalDtype) or t != dtypes[0] for t in dtypes):
        return None
    for dtype in dtypes:
        if isinstance(dtype, pd.CategoricalDtype):
            if len(dtype.categories) > 2**24:
                return None
        elif (not isinstance(dtype, np.dtype) or not dtype.isnative or dtype.kind not in 'biuf'
              or dtype.itemsize not in (1, 2, 4, 8) or dtype.kind == 'f' and dtype.itemsize not in (4, 8)):
            return None
    values, types = np.empty(frame.shape, dtype=np.float32), []
    for index, (name, dtype) in enumerate(zip(frame.columns, dtypes)):
        if isinstance(dtype, pd.CategoricalDtype):
            codes = frame[name].cat.codes.to_numpy()
            values[:, index] = codes
            values[codes == -1, index] = np.nan
            types.append('c')
        else:
            with np.errstate(over='ignore', invalid='ignore'):
                values[:, index] = frame[name].to_numpy(copy=False)
            if np.isinf(values[:, index]).any():
                return None
            types.append('float' if dtype.kind == 'f' else 'i' if dtype.kind == 'b' else 'int')
    return values, types


def _native_xgb_matrix(xgb, frame, *, feature_names, enable_categorical, label=_NO_MATRIX_LABEL, compact_mixed=False):
    """Same native DMatrix validation; avoid pandas dispatch for a qualified dtype.

    Single-block native NumPy columns retain their exact representation and
    explicit pandas feature types. Mixed, extension and categorical data, custom
    frames/constructors and other library versions retain the original route.
    The numeric view shares current storage; no dense consolidation or input
    cache is introduced. Every call rechecks the supported representation.
    Native training may explicitly opt into the bounded mixed-column helper;
    default helper dispatch remains compatible with existing callers.
    """
    data, options = frame, {}
    if (getattr(xgb, '__version__', None) == '2.1.4'
            and pd.__version__ == '3.0.6' and np.__version__ == '2.5.3' and not enable_categorical
            and xgb.DMatrix is getattr(getattr(xgb, 'core', None), 'DMatrix', None)
            and isinstance(xgb.DMatrix, type)
            and type(frame) is pd.DataFrame and len(frame) and len(frame.columns)
            and getattr(frame._mgr, 'is_single_block', False)):
        dtypes = list(frame.dtypes)
        dtype = dtypes[0]
        if (isinstance(dtype, np.dtype) and dtype.isnative
                and dtype.kind in 'biuf' and dtype.itemsize in (1, 2, 4, 8)
                and (dtype.kind != 'f' or dtype.itemsize in (4, 8))
                and all(isinstance(item, np.dtype) and item == dtype for item in dtypes)):
            values = frame.to_numpy(copy=False)
            try:
                shared = np.shares_memory(values, frame._mgr.blocks[0].values, max_work=16)
            except np.exceptions.TooHardError:
                shared = False
            if type(values) is np.ndarray and values.dtype == dtype and shared:
                data = values
                feature_type = 'float' if dtype.kind == 'f' else 'i' if dtype.kind == 'b' else 'int'
                options['feature_types'] = [feature_type] * len(frame.columns)
    if (compact_mixed and data is frame and getattr(xgb, '__version__', None) == '2.1.4'
            and pd.__version__ == '3.0.6' and np.__version__ == '2.5.3'
            and xgb.DMatrix is getattr(getattr(xgb, 'core', None), 'DMatrix', None)
            and isinstance(xgb.DMatrix, type) and type(frame) is pd.DataFrame
            and len(frame) and len(frame.columns)):
        prepared = _small_native_numeric_matrix(frame)
        if prepared is not None and (enable_categorical or 'c' not in prepared[1]):
            data, options['feature_types'] = prepared
    if label is not _NO_MATRIX_LABEL:
        options['label'] = label
    return xgb.DMatrix(data, feature_names=feature_names, enable_categorical=enable_categorical, **options)


def _cat_cols(X: pd.DataFrame) -> List[str]:
    # Native numeric dtypes cannot expose a categorical/string column. Other
    # representations retain their original per-column inspection.
    if (type(X) is pd.DataFrame and all(isinstance(dtype, np.dtype) and dtype.kind in 'biuf'
                                       for dtype in X.dtypes)):
        return []
    out = []
    for c in X.columns:
        if hasattr(X[c], 'cat') or str(X[c].dtype) == 'category':
            out.append(str(c))
        elif X[c].dtype == 'object' or pd.api.types.is_string_dtype(X[c]):
            out.append(str(c))
    return out


def _codes_frame(X: pd.DataFrame, cat_cols: Sequence[str]) -> pd.DataFrame:
    """LightGBM-friendly frame: categoricals as codes, NaN preserved."""
    out = X.copy()
    for c in cat_cols:
        if c not in out.columns:
            continue
        if hasattr(out[c], 'cat'):
            codes = out[c].cat.codes.astype(float)
            codes = codes.replace(-1, np.nan)
            out[c] = codes
        else:
            out[c] = pd.Categorical(out[c]).codes.astype(float)
            out[c] = out[c].replace(-1, np.nan)
    return out


def _is_regression(params: Optional[Dict[str, Any]]) -> bool:
    if not params:
        return False
    task = str(params.get('task') or '').strip().lower()
    if task in ('regression', 'regressor', 'reg'):
        return True
    obj = str(params.get('objective') or '').strip().lower()
    return obj.startswith('reg:') or obj in ('regression', 'rmse', 'mae', 'huber')


class BoosterAdapter(ABC):
    name: str = 'base'

    def __init__(self):
        self.model: Any = None
        self.feature_names: List[str] = []
        self.cat_features: List[str] = []
        self.best_iteration: int = 0
        self.enable_categorical: bool = False
        self.task: str = 'classification'
        self.training_eval_metric: Optional[str] = None
        self.fit_receipt = None
        self.declared_metric_spec = None
        self.stopping_evidence = None

    @abstractmethod
    def train(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        X_valid: pd.DataFrame,
        y_valid: pd.Series,
        params: Dict[str, Any],
        num_boost_round: int = 500,
        early_stopping_rounds: int = 50,
    ) -> 'BoosterAdapter':
        raise NotImplementedError

    @abstractmethod
    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        raise NotImplementedError

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        """Raw score prediction (classification probability or regression value)."""
        return self.predict_proba(X)

    @abstractmethod
    def save(self, path: str) -> str:
        raise NotImplementedError

    @classmethod
    @abstractmethod
    def load(cls, path: str, feature_names: Optional[List[str]] = None,
             cat_features: Optional[List[str]] = None) -> 'BoosterAdapter':
        raise NotImplementedError

    @abstractmethod
    def gain_importance(self) -> List[Dict[str, Any]]:
        raise NotImplementedError

    def shap_model(self) -> Any:
        """Object accepted by shap.TreeExplainer."""
        return self.model

    def model_filename(self, file_id: int) -> str:
        kind = 'regressor' if self.task == 'regression' else 'classifier'
        return f'{file_id}_{self.name}_{kind}.json'


class XGBoostAdapter(BoosterAdapter):
    name = 'xgboost'

    def train(self, X_train, y_train, X_valid, y_valid, params,
              num_boost_round=500, early_stopping_rounds=50):
        self.fit_receipt = None
        import xgboost as xgb
        self.feature_names = list(map(str, X_train.columns))
        self.cat_features = _cat_cols(X_train)
        self.enable_categorical = len(self.cat_features) > 0
        self.task = 'regression' if _is_regression(params) else 'classification'
        spec = prepare_metric(self, params, y_train, y_valid, early_stopping_rounds, num_boost_round)
        p = {k: v for k, v in dict(params).items() if k not in ('task', '_metric_spec')}
        # Normalize sklearn-style aliases to learning-API keys
        if 'learning_rate' in p and 'eta' not in p:
            p['eta'] = p.pop('learning_rate')
        else:
            p.pop('learning_rate', None)
        if 'reg_alpha' in p and 'alpha' not in p:
            p['alpha'] = p.pop('reg_alpha')
        else:
            p.pop('reg_alpha', None)
        if 'reg_lambda' in p and 'lambda' not in p:
            p['lambda'] = p.pop('reg_lambda')
        else:
            p.pop('reg_lambda', None)
        p.pop('n_estimators', None)
        if self.task == 'regression':
            p.setdefault('objective', 'reg:squarederror')
            p.setdefault('eval_metric', 'rmse')
            p.pop('num_class', None)
            p.pop('scale_pos_weight', None)
        self.training_eval_metric = spec['primary_metric'] if spec and early_stopping_rounds else (None if spec else p.get('eval_metric'))
        metric_options, evaluation = {}, {}
        if spec:
            p.pop('eval_metric', None)
            p['disable_default_eval_metric'] = True
            if early_stopping_rounds:
                metric_options = {'custom_metric': lambda predictions, data: (
                    spec['primary_metric'], metric_value(spec, data.get_label(), predictions)),
                    'maximize': spec['direction'] == 'maximize'}
        if self.enable_categorical:
            p['enable_categorical'] = True
        dtrain = _native_xgb_matrix(
            xgb, X_train, label=y_train, feature_names=self.feature_names,
            enable_categorical=self.enable_categorical, compact_mixed=True,
        )
        dvalid = _native_xgb_matrix(
            xgb, X_valid, label=y_valid, feature_names=self.feature_names,
            enable_categorical=self.enable_categorical, compact_mixed=True,
        )
        self.model = xgb.train(
            p, dtrain, num_boost_round=num_boost_round,
            evals=[(dvalid, 'valid')] if not spec or early_stopping_rounds else [],
            early_stopping_rounds=early_stopping_rounds if early_stopping_rounds else None,
            verbose_eval=False, evals_result=evaluation, **metric_options,
        )
        self.best_iteration = int(getattr(self.model, 'best_iteration', num_boost_round - 1))
        record_stopping(self, evaluation.get('valid', {}).get(self.training_eval_metric, []),
                        p.get('objective'), early_stopping_rounds, self.best_iteration + 1)
        from modeling.fit_receipts import record_native_fit
        record_native_fit(self, X_train, y_train, X_valid, y_valid, params, p, num_boost_round, early_stopping_rounds)
        return self

    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        import xgboost as xgb
        frame = X[self.feature_names] if self.feature_names else X
        # A pinned CPU tree with dense float predictors needs no transient
        # DMatrix. Check current names/configuration, then let the native
        # predictor validate the array shape. Other profiles retain DMatrix.
        if (type(self.model) is xgb.Booster and not self.enable_categorical
                and isinstance(frame, pd.DataFrame) and len(frame)
                and all(isinstance(dtype, np.dtype) and dtype.kind == 'f'
                        and dtype.itemsize in (4, 8) and dtype.isnative for dtype in frame.dtypes)
                and self.model.feature_names == list(map(str, frame.columns))
                and self.model.feature_types == ['float'] * len(frame.columns)):
            learner = json.loads(self.model.save_config()).get('learner', {})
            if (learner.get('gradient_booster', {}).get('name') == 'gbtree'
                    and learner.get('generic_param', {}).get('device') == 'cpu'):
                values = frame.to_numpy()
                limit = np.finfo(np.float32).max
                # DMatrix rejects infinities and float32 overflow. NaNs remain
                # supported missing values; unusual numeric ranges keep its
                # original validation rather than broadening accepted inputs.
                if not np.any(values > limit) and not np.any(values < -limit):
                    rounds = (0, int(self.best_iteration) + 1) if self.best_iteration is not None and self.best_iteration >= 0 else (0, 0)
                    return np.asarray(self.model.inplace_predict(values, iteration_range=rounds,
                                                                validate_features=True), dtype=float)
        dmat = _native_xgb_matrix(
            xgb, frame,
            feature_names=self.feature_names or list(map(str, X.columns)),
            enable_categorical=self.enable_categorical,
        )
        if self.best_iteration is not None and self.best_iteration >= 0:
            return np.asarray(
                self.model.predict(dmat, iteration_range=(0, int(self.best_iteration) + 1)),
                dtype=float,
            )
        return np.asarray(self.model.predict(dmat), dtype=float)

    def save(self, path: str) -> str:
        os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
        model = self.model
        if self.best_iteration is not None and 0 <= self.best_iteration < model.num_boosted_rounds() - 1:
            # Native predict defaults to all saved rounds. Publish precisely the
            # evaluated model, excluding patience rounds after its selected round.
            model = model[:self.best_iteration + 1]
            model.set_attr(**self.model.attributes())
        model.save_model(path)
        return path

    @classmethod
    def load(cls, path: str, feature_names=None, cat_features=None):
        import xgboost as xgb
        obj = cls()
        # Model loading and small scoring batches must not create an all-core
        # OpenMP team for every request. Training parallelism is independent.
        obj.model = xgb.Booster(params={'nthread': 1})
        obj.model.load_model(path)
        obj.model.set_param({'nthread': 1})
        obj.feature_names = list(feature_names or [])
        obj.cat_features = list(cat_features or [])
        obj.enable_categorical = bool(obj.cat_features)
        obj.task = 'regression' if 'regressor' in os.path.basename(path).lower() else 'classification'
        try:
            saved_iteration = getattr(obj.model, 'best_iteration', None)
            obj.best_iteration = int(saved_iteration) if saved_iteration is not None else None
        except Exception:
            obj.best_iteration = None
        return obj

    def gain_importance(self) -> List[Dict[str, Any]]:
        try:
            raw = self.model.get_score(importance_type='gain')
        except Exception:
            return []
        items = sorted(((str(k), float(v)) for k, v in raw.items()), key=lambda kv: kv[1], reverse=True)
        # Strip f-prefix / map to feature names when possible
        out = []
        for k, v in items:
            name = k
            if k.startswith('f') and k[1:].isdigit() and self.feature_names:
                idx = int(k[1:])
                if 0 <= idx < len(self.feature_names):
                    name = self.feature_names[idx]
            out.append({'feature': name, 'score': v})
        return out

    def model_filename(self, file_id: int) -> str:
        kind = 'regressor' if self.task == 'regression' else 'classifier'
        return f'{file_id}_xgb_{kind}.json'


class LightGBMAdapter(BoosterAdapter):
    name = 'lightgbm'

    def train(self, X_train, y_train, X_valid, y_valid, params,
              num_boost_round=500, early_stopping_rounds=50):
        self.fit_receipt = None
        import lightgbm as lgb
        self.feature_names = list(map(str, X_train.columns))
        self.cat_features = _cat_cols(X_train)
        self.enable_categorical = len(self.cat_features) > 0
        self.task = 'regression' if _is_regression(params) else 'classification'
        spec = prepare_metric(self, params, y_train, y_valid, early_stopping_rounds, num_boost_round)
        Xtr = X_train.copy()
        Xva = X_valid.copy()
        # LightGBM prefers category dtype for native cats
        for c in self.cat_features:
            if c in Xtr.columns:
                Xtr[c] = Xtr[c].astype('category')
            if c in Xva.columns:
                Xva[c] = Xva[c].astype('category')
        p = {
            'objective': 'binary',
            'metric': 'auc',
            'verbosity': -1,
            'seed': int(params.get('seed', 42)),
            'learning_rate': float(params.get('eta', params.get('learning_rate', 0.05))),
            'max_depth': int(params.get('max_depth', 4)),
            'min_child_weight': float(params.get('min_child_weight', 2)),
            'subsample': float(params.get('subsample', 0.8)),
            'colsample_bytree': float(params.get('colsample_bytree', 0.7)),
            'reg_alpha': float(params.get('alpha', params.get('reg_alpha', 0.1))),
            'reg_lambda': float(params.get('lambda', params.get('reg_lambda', 1.5))),
            'min_split_gain': float(params.get('gamma', params.get('min_split_gain', 0.0))),
            'num_threads': int(params.get('nthread', params.get('num_threads', 0)) or 0),
        }
        if self.task == 'regression':
            p['objective'] = 'regression'
            p['metric'] = 'rmse'
        elif 'num_class' in params:
            p['objective'] = 'multiclass'
            p['num_class'] = int(params['num_class'])
            p['metric'] = 'multi_logloss'
        if 'scale_pos_weight' in params and self.task != 'regression':
            p['scale_pos_weight'] = float(params['scale_pos_weight'])
        self.training_eval_metric = spec['primary_metric'] if spec and early_stopping_rounds else (None if spec else p['metric'])
        metric_options, evaluation = {}, {}
        if spec:
            p['metric'] = 'None'
            if early_stopping_rounds:
                metric_options['feval'] = lambda predictions, data: (
                    spec['primary_metric'], metric_value(spec, data.get_label(), predictions),
                    spec['direction'] == 'maximize')
        dtrain = lgb.Dataset(Xtr, label=y_train, categorical_feature=self.cat_features or 'auto', free_raw_data=False)
        dvalid = lgb.Dataset(Xva, label=y_valid, reference=dtrain, categorical_feature=self.cat_features or 'auto', free_raw_data=False)
        callbacks = [lgb.log_evaluation(period=0), lgb.record_evaluation(evaluation)]
        if early_stopping_rounds:
            callbacks.append(lgb.early_stopping(early_stopping_rounds, verbose=False, first_metric_only=True))
        self.model = lgb.train(
            p, dtrain, num_boost_round=num_boost_round,
            valid_sets=[dvalid] if not spec or early_stopping_rounds else [], valid_names=['valid'] if not spec or early_stopping_rounds else [],
            callbacks=callbacks, **metric_options,
        )
        self.best_iteration = int(self.model.best_iteration or self.model.current_iteration())
        record_stopping(self, evaluation.get('valid', {}).get(self.training_eval_metric, []),
                        p['objective'], early_stopping_rounds, self.best_iteration)
        from modeling.fit_receipts import record_native_fit
        record_native_fit(self, X_train, y_train, X_valid, y_valid, params, p, num_boost_round, early_stopping_rounds)
        return self

    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        Xc = X[self.feature_names].copy() if self.feature_names else X.copy()
        for c in self.cat_features:
            if c in Xc.columns:
                Xc[c] = Xc[c].astype('category')
        ntree = self.best_iteration if self.best_iteration and self.best_iteration > 0 else None
        return np.asarray(self.model.predict(Xc, num_iteration=ntree), dtype=float)

    def save(self, path: str) -> str:
        os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
        self.model.save_model(path)
        return path

    @classmethod
    def load(cls, path: str, feature_names=None, cat_features=None):
        import lightgbm as lgb
        obj = cls()
        obj.model = lgb.Booster(model_file=path)
        obj.feature_names = list(feature_names or obj.model.feature_name() or [])
        obj.cat_features = list(cat_features or [])
        obj.enable_categorical = bool(obj.cat_features)
        obj.task = 'regression' if 'regressor' in os.path.basename(path).lower() else 'classification'
        obj.best_iteration = int(getattr(obj.model, 'best_iteration', 0) or 0)
        return obj

    def gain_importance(self) -> List[Dict[str, Any]]:
        try:
            names = self.feature_names or self.model.feature_name()
            gains = self.model.feature_importance(importance_type='gain')
            pairs = sorted(zip(names, gains), key=lambda kv: float(kv[1]), reverse=True)
            return [{'feature': str(k), 'score': float(v)} for k, v in pairs if float(v) > 0]
        except Exception:
            return []

    def model_filename(self, file_id: int) -> str:
        kind = 'regressor' if self.task == 'regression' else 'classifier'
        return f'{file_id}_lgbm_{kind}.txt'


class CatBoostAdapter(BoosterAdapter):
    name = 'catboost'

    def train(self, X_train, y_train, X_valid, y_valid, params,
              num_boost_round=500, early_stopping_rounds=50):
        self.fit_receipt = None
        from catboost import CatBoostClassifier, CatBoostRegressor, Pool
        self.feature_names = list(map(str, X_train.columns))
        self.cat_features = _cat_cols(X_train)
        self.enable_categorical = len(self.cat_features) > 0
        self.task = 'regression' if _is_regression(params) else 'classification'
        spec = prepare_metric(self, params, y_train, y_valid, early_stopping_rounds, num_boost_round)
        cat_idx = [self.feature_names.index(c) for c in self.cat_features if c in self.feature_names]
        Xtr = X_train.copy()
        Xva = X_valid.copy()
        for c in self.cat_features:
            Xtr[c] = Xtr[c].astype(str).fillna('__NULL__')
            Xva[c] = Xva[c].astype(str).fillna('__NULL__')
        train_pool = Pool(Xtr, y_train, cat_features=cat_idx or None, feature_names=self.feature_names)
        valid_pool = Pool(Xva, y_valid, cat_features=cat_idx or None, feature_names=self.feature_names)
        cb_kwargs: Dict[str, Any] = {
            'iterations': int(num_boost_round),
            'learning_rate': float(params.get('eta', params.get('learning_rate', 0.05))),
            'depth': int(params.get('max_depth', 4)),
            'l2_leaf_reg': float(params.get('lambda', params.get('reg_lambda', 1.5))),
            'subsample': float(params.get('subsample', 0.8)),
            'rsm': float(params.get('colsample_bytree', params.get('rsm', 0.8))),
            'min_data_in_leaf': int(params.get('min_child_weight', params.get('min_data_in_leaf', 1))),
            'random_seed': int(params.get('seed', 42)),
            'thread_count': int(params.get('nthread', params.get('thread_count', -1)) or -1),
            'verbose': False,
            'allow_writing_files': False,
            'use_best_model': bool(early_stopping_rounds),
        }
        if self.task == 'regression':
            cb_kwargs['loss_function'] = 'RMSE'
            cb_kwargs['eval_metric'] = CatBoostDeclaredMetric(spec) if spec and early_stopping_rounds else 'RMSE'
            self.model = CatBoostRegressor(**cb_kwargs)
        else:
            loss = 'MultiClass' if 'num_class' in params else 'Logloss'
            cb_kwargs['loss_function'] = loss
            cb_kwargs['eval_metric'] = CatBoostDeclaredMetric(spec) if spec and early_stopping_rounds else ('AUC' if loss == 'Logloss' else 'MultiClass')
            if loss == 'MultiClass':
                # CatBoost's default multiclass Bayesian bootstrap rejects
                # the shared subsample setting. Bernoulli supports that setting.
                cb_kwargs['bootstrap_type'] = 'Bernoulli'
            if 'scale_pos_weight' in params and params['scale_pos_weight'] is not None:
                cb_kwargs['scale_pos_weight'] = float(params['scale_pos_weight'])
            self.model = CatBoostClassifier(**cb_kwargs)
        self.training_eval_metric = spec['primary_metric'] if spec and early_stopping_rounds else (None if spec else cb_kwargs['eval_metric'])
        self.model.fit(
            train_pool, eval_set=valid_pool if not spec or early_stopping_rounds else None,
            early_stopping_rounds=early_stopping_rounds or None,
            verbose=False,
        )
        best = self.model.get_best_iteration()
        self.best_iteration = int(best if early_stopping_rounds and best >= 0 else self.model.tree_count_ - 1)
        evaluation = self.model.get_evals_result().get('validation', {})
        record_stopping(self, evaluation.get('CatBoostDeclaredMetric', []), cb_kwargs['loss_function'],
                        early_stopping_rounds, self.model.tree_count_)
        from modeling.fit_receipts import record_native_fit
        record_native_fit(self, X_train, y_train, X_valid, y_valid, params, self.model.get_all_params(), num_boost_round, early_stopping_rounds)
        return self

    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        from catboost import Pool
        Xc = X[self.feature_names].copy() if self.feature_names else X.copy()
        for c in self.cat_features:
            if c in Xc.columns:
                Xc[c] = Xc[c].astype(str).fillna('__NULL__')
        cat_idx = [list(Xc.columns).index(c) for c in self.cat_features if c in Xc.columns]
        pool = Pool(Xc, cat_features=cat_idx or None, feature_names=list(map(str, Xc.columns)))
        if self.task == 'regression' or not hasattr(self.model, 'predict_proba'):
            return np.asarray(self.model.predict(pool), dtype=float).ravel()
        proba = self.model.predict_proba(pool)
        proba = np.asarray(proba)
        if proba.ndim == 2 and proba.shape[1] > 2:
            return proba.astype(float)
        if proba.ndim == 2 and proba.shape[1] == 2:
            return proba[:, 1].astype(float)
        return proba.ravel().astype(float)

    def save(self, path: str) -> str:
        os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
        self.model.save_model(path)
        return path

    @classmethod
    def load(cls, path: str, feature_names=None, cat_features=None):
        from catboost import CatBoostClassifier, CatBoostRegressor
        obj = cls()
        is_reg = 'regressor' in os.path.basename(path).lower()
        obj.task = 'regression' if is_reg else 'classification'
        obj.model = CatBoostRegressor() if is_reg else CatBoostClassifier()
        obj.model.load_model(path)
        obj.feature_names = list(feature_names or [])
        obj.cat_features = list(cat_features or [])
        obj.enable_categorical = bool(obj.cat_features)
        try:
            obj.best_iteration = int(obj.model.get_best_iteration() or 0)
        except Exception:
            obj.best_iteration = 0
        return obj

    def gain_importance(self) -> List[Dict[str, Any]]:
        try:
            importances = self.model.get_feature_importance()
            names = self.feature_names or [f'f{i}' for i in range(len(importances))]
            pairs = sorted(zip(names, importances), key=lambda kv: float(kv[1]), reverse=True)
            return [{'feature': str(k), 'score': float(v)} for k, v in pairs if float(v) > 0]
        except Exception:
            return []

    def model_filename(self, file_id: int) -> str:
        kind = 'regressor' if self.task == 'regression' else 'classifier'
        return f'{file_id}_catboost_{kind}.cbm'


_ADAPTERS = {
    'xgboost': XGBoostAdapter,
    'lightgbm': LightGBMAdapter,
    'catboost': CatBoostAdapter,
}


def available_boosting_algorithms() -> Dict[str, bool]:
    """Return {algo: importable?} for UI/API honesty."""
    status = {'xgboost': True, 'lightgbm': False, 'catboost': False}
    try:
        import lightgbm  # noqa: F401
        status['lightgbm'] = True
    except Exception:
        pass
    try:
        import catboost  # noqa: F401
        status['catboost'] = True
    except Exception:
        pass
    try:
        import xgboost  # noqa: F401
        status['xgboost'] = True
    except Exception:
        status['xgboost'] = False
    return status


def config_to_booster_params(
    config: Dict[str, Any],
    *,
    task: str = 'classification',
    nthread: int = 0,
    scale_pos_weight: Optional[float] = None,
    seed: int = 42,
) -> Tuple[Dict[str, Any], int]:
    """Map shared HP/SFS config knobs into adapter ``train`` params + num_boost_round.

    Shared knobs: n_estimators, max_depth, learning_rate, min_child_weight,
    subsample, colsample_bytree, gamma, reg_alpha, reg_lambda.
    Adapters accept both sklearn-style and XGBoost learning-API aliases.
    """
    task_l = 'regression' if str(task or '').strip().lower() in (
        'regression', 'regressor', 'reg',
    ) else 'classification'
    num_boost_round = int(config.get('n_estimators', 200))
    params: Dict[str, Any] = {
        'seed': seed,
        'task': task_l,
        'learning_rate': float(config.get('learning_rate', config.get('eta', 0.1))),
        'eta': float(config.get('learning_rate', config.get('eta', 0.1))),
        'max_depth': int(config.get('max_depth', 6)),
        'min_child_weight': float(config.get('min_child_weight', 1)),
        'subsample': float(config.get('subsample', 0.8)),
        'colsample_bytree': float(config.get('colsample_bytree', 0.8)),
        'gamma': float(config.get('gamma', 0.0)),
        'reg_alpha': float(config.get('reg_alpha', config.get('alpha', 0.0))),
        'alpha': float(config.get('reg_alpha', config.get('alpha', 0.0))),
        'reg_lambda': float(config.get('reg_lambda', config.get('lambda', 1.0))),
        'lambda': float(config.get('reg_lambda', config.get('lambda', 1.0))),
        'nthread': int(nthread),
    }
    if task_l == 'regression':
        params['objective'] = 'reg:squarederror'
        params['eval_metric'] = 'rmse'
    else:
        params['objective'] = 'binary:logistic'
        params['eval_metric'] = 'auc'
        if scale_pos_weight is not None and np.isfinite(scale_pos_weight) and scale_pos_weight > 0:
            params['scale_pos_weight'] = float(scale_pos_weight)
    if config.get('_metric_spec'):
        params['_metric_spec'] = config['_metric_spec']
    return params, num_boost_round


def fit_booster(
    algorithm: Optional[str],
    X_train: pd.DataFrame,
    y_train: pd.Series,
    X_valid: pd.DataFrame,
    y_valid: pd.Series,
    config: Optional[Dict[str, Any]] = None,
    *,
    task: str = 'classification',
    nthread: int = 0,
    scale_pos_weight: Optional[float] = None,
    num_boost_round: Optional[int] = None,
    early_stopping_rounds: int = 50,
) -> BoosterAdapter:
    """Train a booster for the given algorithm from a shared config dict."""
    cfg = dict(config or {})
    params, n_rounds = config_to_booster_params(
        cfg, task=task, nthread=nthread, scale_pos_weight=scale_pos_weight,
    )
    if num_boost_round is not None:
        n_rounds = int(num_boost_round)
    adapter = get_adapter(algorithm)
    adapter.train(
        X_train, y_train, X_valid, y_valid, params,
        num_boost_round=n_rounds,
        early_stopping_rounds=early_stopping_rounds if early_stopping_rounds else 0,
    )
    return adapter


def get_adapter(algorithm: Optional[str] = None) -> BoosterAdapter:
    algo = (algorithm or 'xgboost').strip().lower()
    if algo not in _ADAPTERS:
        raise ValueError(f'Unsupported boosting algorithm: {algorithm}')
    avail = available_boosting_algorithms()
    if not avail.get(algo):
        raise ImportError(
            f'{algo} is not installed in this environment. '
            f'Install the package or select an available booster: '
            f'{[k for k, v in avail.items() if v]}'
        )
    return _ADAPTERS[algo]()


def load_adapter_from_path(
    path: str,
    algorithm: Optional[str] = None,
    feature_names: Optional[List[str]] = None,
    cat_features: Optional[List[str]] = None,
) -> BoosterAdapter:
    algo = (algorithm or 'xgboost').strip().lower()
    lower = path.lower()
    if algorithm is None:
        if lower.endswith('.cbm') or 'catboost' in lower:
            algo = 'catboost'
        elif lower.endswith('.txt') or 'lgbm' in lower or 'lightgbm' in lower:
            algo = 'lightgbm'
        else:
            algo = 'xgboost'
    cls = _ADAPTERS[algo]
    return cls.load(path, feature_names=feature_names, cat_features=cat_features)
