from execution_jobs.views import DatasetJobHistoryView, JobOperationalHandoffView, NativeAdoptionListView, NativeAdoptionView, NativeProtectedInputView, NativeAssessmentInputView, JobCandidateExportView, JobCandidateInputView, DatasetJobsView, JobDetailView, JobInputView, JobScoresView, JobTrainingInputView
from access_control.project_views import ProjectListView, ProjectMemberView
from access_control.assistant_views import AssistantApprovalView, AssistantApproveView, AssistantCancelView, AssistantReceiptView
from django.contrib import admin
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from declaration.views import DeclarationViewSet
from feature_card.views import FeatureCardViewSet
from preprocessing.views import PreprocessingApplyView, PreprocessingOptionsView, PreprocessingRunView, PreprocessingDatqDetailView, PreprocessingDatqTimeseriesView, PreprocessingDatqSummaryRowView, PreprocessingStatusView
from modeling.views import ModelingStartView, ModelingStatusView, FeatureExplainabilityView, SFSResultsView, SFSStartView, SFSStatusView, SFSStopView, VifDetailView, PipelineRunListView, PipelineRunCreateView, PipelineRunDetailView, PipelineReportView, HyperparamStartView, HyperparamStatusView, HyperparamStopView, HyperparamResultsView, ChampionPromoteView, SFSHistoryView, BoosterCompareView
from modeling.crisp_views import (
    CrispExportPackView, CrispMonitoringRunView, CrispSequentialPatternsView,
    CrispIterationCloneView, CrispDatqEnrichView,
)
from encoding.views import EncodingAnalyzeView, EncodingApplyView
from evaluation.views import EvaluationRunView, EvaluationStatusView, EvaluationPackView, GovernanceChecksView, HoldoutHistoryView
from deployment.views import DeploymentBundleView, DeploymentScoreView, DeploymentStatusView, DeploymentPackView, DeploymentReceiptView
from deployment.review_views import PackageReviewListView, PackageReviewDetailView, PackageReviewReceiptView
from ai_assistant.feedback import AIFeedbackView
from ai_assistant.views import AIAssistantView, AIActionExecuteView, AICachePushView, AIModelListView
from backend.auth_views import session_status, session_login, session_logout, protected_media

router = DefaultRouter()
router.register(r'declaration', DeclarationViewSet)
router.register(r'feature-card', FeatureCardViewSet, basename='feature-card')

urlpatterns = [
    path('api/projects/', ProjectListView.as_view(), name='project-list'),
    path('api/projects/<uuid:project_id>/members/', ProjectMemberView.as_view(), name='project-member'),
    path('api/auth/session/', session_status, name='auth-session'),
    path('api/auth/login/', session_login, name='auth-login'),
    path('api/auth/logout/', session_logout, name='auth-logout'),
    path('media/<path:path>', protected_media, name='protected-media'),
    path('admin/', admin.site.urls),
    path('api/', include(router.urls)),
    path('api/feature-card/<int:pk>/get_stacked_feature_data/', FeatureCardViewSet.as_view({'get': 'get_stacked_feature_data'}), name='get-stacked-feature-data'),
    path('api/preprocessing/apply/', PreprocessingApplyView.as_view(), name='preprocessing-apply'),
    path('api/preprocessing/options/', PreprocessingOptionsView.as_view(), name='preprocessing-options'),
    path('api/preprocessing/run/', PreprocessingRunView.as_view(), name='preprocessing-run'),
    path('api/preprocessing/datq_detail/', PreprocessingDatqDetailView.as_view(), name='preprocessing-datq-detail'),
    path('api/preprocessing/datq_timeseries/', PreprocessingDatqTimeseriesView.as_view(), name='preprocessing-datq-timeseries'),
    path('api/preprocessing/datq_summary_row/<int:file_id>/', PreprocessingDatqSummaryRowView.as_view(), name='preprocessing-datq-summary-row'),
    path('api/preprocessing/status/<int:file_id>/', PreprocessingStatusView.as_view(), name='preprocessing-status'),
    path('api/modeling/start/', ModelingStartView.as_view(), name='modeling-start'),
    path('api/modeling/status/<int:file_id>/', ModelingStatusView.as_view(), name='modeling-status'),
    path('api/modeling/feature-explainability/', FeatureExplainabilityView.as_view(), name='feature-explainability'),
    path('api/modeling/sfs/start/', SFSStartView.as_view(), name='sfs-start'),
    path('api/modeling/sfs/status/<int:file_id>/', SFSStatusView.as_view(), name='sfs-status'),
    path('api/modeling/sfs/stop/<int:file_id>/', SFSStopView.as_view(), name='sfs-stop'),
    path('api/modeling/sfs/<int:file_id>/', SFSResultsView.as_view(), name='sfs-results'),
    path('api/modeling/hyperparam/start/', HyperparamStartView.as_view(), name='hyperparam-start'),
    path('api/modeling/hyperparam/status/<int:file_id>/', HyperparamStatusView.as_view(), name='hyperparam-status'),
    path('api/modeling/hyperparam/stop/<int:file_id>/', HyperparamStopView.as_view(), name='hyperparam-stop'),
    path('api/modeling/hyperparam/<int:file_id>/', HyperparamResultsView.as_view(), name='hyperparam-results'),
    path('api/encoding/analyze/', EncodingAnalyzeView.as_view(), name='encoding-analyze'),
    path('api/encoding/apply/', EncodingApplyView.as_view(), name='encoding-apply'),
    path('api/modeling/vif-detail/', VifDetailView.as_view(), name='vif-detail'),
    path('api/evaluation/run/', EvaluationRunView.as_view(), name='evaluation-run'),
    path('api/evaluation/status/<int:file_id>/', EvaluationStatusView.as_view(), name='evaluation-status'),
    path('api/evaluation/holdout-history/<uuid:execution_id>/', HoldoutHistoryView.as_view(), name='holdout-history'),
    path('api/evaluation/pack/', EvaluationPackView.as_view(), name='evaluation-pack'),
    path('api/evaluation/governance/', GovernanceChecksView.as_view(), name='evaluation-governance'),
    path('api/deployment/bundle/', DeploymentBundleView.as_view(), name='deployment-bundle'),
    path('api/deployment/score/', DeploymentScoreView.as_view(), name='deployment-score'),
    path('api/deployment/receipts/<int:file_id>/<uuid:batch_id>/', DeploymentReceiptView.as_view(), name='deployment-receipt'),
    path('api/deployment/status/<int:file_id>/', DeploymentStatusView.as_view(), name='deployment-status'),
    path('api/deployment/pack/', DeploymentPackView.as_view(), name='deployment-pack'),
    path('api/jobs/datasets/<int:file_id>/training-input/', JobTrainingInputView.as_view(), name='job-training-input'),
    path('api/jobs/datasets/<int:file_id>/', DatasetJobsView.as_view(), name='dataset-jobs'),
    path('api/jobs/datasets/<int:file_id>/history/', DatasetJobHistoryView.as_view(), name='dataset-job-history'),
    path('api/jobs/datasets/<int:file_id>/input/', JobInputView.as_view(), name='job-input'),
    path('api/jobs/<uuid:job_id>/adoptions/', NativeAdoptionListView.as_view(), name='native-adoption-list'),
    path('api/native-adoptions/<uuid:adoption_id>/', NativeAdoptionView.as_view(), name='native-adoption'),
    path('api/native-adoptions/<uuid:adoption_id>/protected-inputs/', NativeProtectedInputView.as_view(), name='native-protected-input'),
    path('api/native-protected-inputs/<uuid:protected_id>/preview/', NativeAssessmentInputView.as_view(), name='native-assessment-input'),
    path('api/jobs/<uuid:job_id>/candidate/', JobCandidateExportView.as_view(), name='job-candidate'),
    path('api/jobs/<uuid:job_id>/scoring-input/', JobCandidateInputView.as_view(), name='job-candidate-input'),
    path('api/jobs/<uuid:job_id>/scores/', JobScoresView.as_view(), name='job-scores'),
    path('api/jobs/<uuid:job_id>/operational-handoff/', JobOperationalHandoffView.as_view(), name='job-operational-handoff'),
    path('api/jobs/<uuid:job_id>/', JobDetailView.as_view(), name='job-detail'),
    path('api/reviews/datasets/<int:file_id>/', PackageReviewListView.as_view(), name='package-review-list'),
    path('api/reviews/<uuid:review_id>/', PackageReviewDetailView.as_view(), name='package-review-detail'),
    path('api/reviews/<uuid:review_id>/events/<uuid:event_id>/receipt/', PackageReviewReceiptView.as_view(), name='package-review-receipt'),
    path('api/crisp/export/', CrispExportPackView.as_view(), name='crisp-export'),
    path('api/crisp/monitoring/', CrispMonitoringRunView.as_view(), name='crisp-monitoring'),
    path('api/crisp/iteration/clone/', CrispIterationCloneView.as_view(), name='crisp-iteration-clone'),
    path('api/crisp/sequential/<int:file_id>/', CrispSequentialPatternsView.as_view(), name='crisp-sequential'),
    path('api/crisp/datq/<int:file_id>/', CrispDatqEnrichView.as_view(), name='crisp-datq'),
    path('api/modeling/sfs/<int:file_id>/history/', SFSHistoryView.as_view(), name='sfs-history'),
    path('api/modeling/champion/', ChampionPromoteView.as_view(), name='champion-promote'),
    path('api/modeling/compare/<int:file_id>/', BoosterCompareView.as_view(), name='booster-compare'),
    path('api/pipeline/', PipelineRunListView.as_view(), name='pipeline-list'),
    path('api/pipeline/create/', PipelineRunCreateView.as_view(), name='pipeline-create'),
    path('api/pipeline/<int:pk>/', PipelineRunDetailView.as_view(), name='pipeline-detail'),
    path('api/pipeline/<int:pk>/report/', PipelineReportView.as_view(), name='pipeline-report'),
    path('api/ai-assistant/chat/', AIAssistantView.as_view(), name='ai-assistant-chat'),
    path('api/ai-assistant/execute-action/', AIActionExecuteView.as_view(), name='ai-assistant-execute-action'),
    path('api/ai-assistant/prepare-action/', AssistantApprovalView.as_view(), name='assistant-prepare-action'),
    path('api/ai-assistant/approve-action/', AssistantApproveView.as_view(), name='assistant-approve-action'),
    path('api/ai-assistant/cancel-action/', AssistantCancelView.as_view(), name='assistant-cancel-action'),
    path('api/ai-assistant/action-approval/<uuid:approval_id>/', AssistantReceiptView.as_view(), name='assistant-action-receipt'),
    path('api/ai-assistant/feedback/', AIFeedbackView.as_view(), name='ai-assistant-feedback'),
    path('api/ai-assistant/cache/', AICachePushView.as_view(), name='ai-assistant-cache'),
    path('api/ai-assistant/models/', AIModelListView.as_view(), name='ai-assistant-models'),
]
