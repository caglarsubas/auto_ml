"""Durable native requests and append-only receipts, never Celery result state."""

import uuid
from django.conf import settings
from django.db import models
from django.utils import timezone
from execution_jobs.metadata_json import NativeJSONField


class QueueLock(models.Model):
    id = models.PositiveSmallIntegerField(primary_key=True, default=1)


class NativeJob(models.Model):
    id = models.UUIDField(primary_key=True, editable=False)
    project = models.ForeignKey("access_control.Project", on_delete=models.PROTECT)
    dataset = models.ForeignKey("declaration.Declaration", on_delete=models.PROTECT)
    source_dataset = models.ForeignKey("declaration.Declaration", null=True, on_delete=models.PROTECT, related_name="scoring_jobs")
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL)
    actor_snapshot = NativeJSONField()
    authority = NativeJSONField()
    specification = NativeJSONField()
    request_sha256 = models.CharField(max_length=64)
    state = models.CharField(max_length=24, default="queued")
    revision = models.PositiveIntegerField(default=0)
    attempts = models.PositiveSmallIntegerField(default=0)
    lease_token = models.UUIDField(null=True)
    lease_until = models.DateTimeField(null=True)
    next_dispatch = models.DateTimeField(default=timezone.now)
    expires_at = models.DateTimeField()
    result = NativeJSONField(null=True)
    result_sha256 = models.CharField(max_length=64, blank=True)
    reason_code = models.CharField(max_length=64, blank=True)
    created_at = models.DateTimeField(default=timezone.now)
    finished_at = models.DateTimeField(null=True)

    class Meta:
        indexes = [models.Index(fields=["state", "next_dispatch"])]


class JobEvent(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    job = models.ForeignKey(NativeJob, on_delete=models.PROTECT, related_name="events")
    revision = models.PositiveIntegerField()
    event_type = models.CharField(max_length=32)
    actor_snapshot = NativeJSONField(default=dict)
    detail = NativeJSONField(default=dict)
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ["revision"]
        constraints = [models.UniqueConstraint(fields=["job", "revision"], name="job_event_revision_unique")]


class NativeAdoption(models.Model):
    """Immutable developer proposal; independent decisions are separate events."""
    id = models.UUIDField(primary_key=True, editable=False)
    training_job = models.ForeignKey(NativeJob, on_delete=models.PROTECT, related_name='adoptions')
    proposal = NativeJSONField()
    proposal_sha256 = models.CharField(max_length=64)
    request_sha256 = models.CharField(max_length=64)
    created_at = models.DateTimeField(default=timezone.now)


class NativeAdoptionEvent(models.Model):
    id = models.UUIDField(primary_key=True, editable=False)
    adoption = models.ForeignKey(NativeAdoption, on_delete=models.PROTECT, related_name='events')
    revision = models.PositiveIntegerField()
    kind = models.CharField(max_length=16)
    payload = NativeJSONField()
    payload_sha256 = models.CharField(max_length=64)
    request_sha256 = models.CharField(max_length=64)
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ['revision']
        constraints = [models.UniqueConstraint(fields=['adoption', 'revision'], name='native_adoption_event_revision')]


class NativeProtectedInput(models.Model):
    """Sealed custody bytes; never a generic dataset, artifact URL or job payload."""
    id = models.UUIDField(primary_key=True, editable=False)
    adoption = models.ForeignKey(NativeAdoption, on_delete=models.PROTECT, related_name='protected_inputs')
    specification = NativeJSONField()
    specification_sha256 = models.CharField(max_length=64)
    request_sha256 = models.CharField(max_length=64)
    payload = models.BinaryField()
    created_at = models.DateTimeField(default=timezone.now)
